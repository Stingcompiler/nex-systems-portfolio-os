# رزمة الإصلاحات — stingdev

ملفات كاملة جاهزة للاستبدال، ورقع صغيرة لملفات لم تكن تحتاج إعادة كتابة.
الأرقام بين قوسين تشير إلى بنود التدقيق في وثيقة «لغة التصميم».

## 1) استبدال مباشر (انسخ فوق الملف الأصلي)

| الملف | ما تغيّر |
|---|---|
| `tailwind.config.ts` | حذف `lineHeight` من `display/h1/h2/h3` (1) · درجات `soft` لكل لون دلالي (4) · مقياس `body-lg` |
| `src/app/globals.css` | تعريف `success/warning/danger` في `.dark` (2) · الارتفاع بالحدّ في الداكن (3) · رموز `soft` (4) · `letter-spacing` على `:lang(ar)` بلا `!important` (5) · قلب توهّج الـHero في RTL ولون من الرمز (6) · `.truncate-line` (12) · `.code-inline` · `.prose-content` بلون كامل (14) |
| `src/components/ui/button.tsx` | نوع `danger` وحالة `loading` مع `aria-busy` (11) · حجم `icon` · مكوّن `IconButton` بهدف 44px و`label` إلزامي (7) |
| `src/components/ui/misc.tsx` | نبرات `Badge` الدلالية من رموز `soft` (4، 14) · `Breadcrumbs` يأخذ `label` مترجَمًا (8) |
| `src/components/ui/states.tsx` | خيار `bare` ليعمل المكوّنان داخل `<td colSpan>` (10) · خلفيات من رموز `soft` |
| `src/features/dashboard/resource/resource-page.tsx` | كل النصوص من `dashboard.*` (8) · أزرار الصف 44px (7) · سهم واحد بـ`flip-rtl` (9) · `EmptyState/ErrorState` المشتركان مع إجراء مقترح (10) · `Button` بدل الأزرار اليدوية (11) · `truncate-line` بدل `line-clamp-1` (12) · تسمية مرئية للبحث والفلاتر · عمود الإجراءات `text-end` |
| `src/components/content/cards.tsx` | `DirectionArrow` بلا تفريع على اللغة (9) · شارة «مميّزة» نصًا مترجمًا بدل `★` · `code-inline` للأسعار والتواريخ · حذف `leading-relaxed` (13) |

## 2) مفاتيح الترجمة

`src/messages/_additions.json` يحوي كتلتَي `ar` و`en`. ادمج محتوى كل كتلة في ملفها المقابل
(`ar.json` / `en.json`). `pagination.summary` يستخدم `t.rich` مع وسم `<ltr>` لعزل الأرقام.

## 3) رقع صغيرة (عدّل يدويًا)

### `src/components/sections/home.tsx`

```diff
-import { ArrowLeft, ArrowRight, Check } from 'lucide-react';
+import { ArrowLeft, Check } from 'lucide-react';

-  const Arrow = locale === 'ar' ? ArrowLeft : ArrowRight;      // (9) في HeroSection وCtaSection
-  <Arrow className="size-4" aria-hidden="true" />
+  <ArrowLeft className="size-4 flip-rtl" aria-hidden="true" />

-  <h1 className="text-display font-bold tracking-tight">      // (13)
+  <h1 className="text-display font-bold">

-  <p className="mt-5 max-w-prose text-lg leading-relaxed text-muted">   // (13)
+  <p className="mt-5 max-w-prose text-body-lg text-muted">

-  <span className="mb-3 inline-flex size-8 … text-primary">     // ProcessSection (14)
-    <span dir="ltr">{index + 1}</span>
+  <span className="mb-3 inline-flex size-8 … bg-primary-soft text-primary">
+    <span className="code-inline inline">{index + 1}</span>

-  <div className="hero-surface relative overflow-hidden rounded-2xl bg-brand …">  // CtaSection
+  <div className="hero-surface brand-panel relative overflow-hidden rounded-2xl bg-brand …">
```

`brand-panel` يلغي الشبكة النقطية فوق التدرّج (معرَّفة في `globals.css` الجديد) — التدرّج والشبكة معًا يعطيان سطحًا موحلًا.

بعد التعديل احذف `locale` من `props` إن لم يعد مستخدمًا في القسم.

### `src/components/ui/section.tsx`

```diff
-        tone === 'muted' && 'bg-surface/60 border-y border-border',   // (14)
+        tone === 'muted' && 'bg-surface border-y border-border',
```

مع الشريط المتدرّج قبل العنوان: `before:-top-4` يعتمد على ارتفاع سطر 1.2؛ بعد إصلاح البند 1
صار ارتفاع العنوان العربي 1.5، فاجعلها `before:-top-5` كي لا يلتصق الشريط بالحرف.

### `src/components/layout/header.tsx`

```diff
-          className="flex items-center gap-2 text-lg font-bold tracking-normal"
+          className="flex items-center gap-2 text-lg font-bold"
```

روابط التنقل: `rounded` → `rounded-lg` لتوحيد الحواف مع بقية الأزرار.

### أي استدعاء لـ `Breadcrumbs`

```diff
-<Breadcrumbs items={items} />
+<Breadcrumbs items={items} label={t('common.breadcrumbs')} />
```

## 4) ترتيب التطبيق

1. `tailwind.config.ts` + `globals.css` — الرموز أولًا وإلا فشلت أصناف `*-soft`.
2. مفاتيح الترجمة.
3. مكوّنات `ui/` الثلاثة.
4. `resource-page.tsx` ثم `cards.tsx`.
5. الرقع الصغيرة.

## 5) اختبار بعد التطبيق

- `/ar` و`/en` في الوضعين، على 375px و768px و1440px.
- أسهم الترقيم والبطاقات: تشير للأمام في اللغتين.
- Tab عبر صف في الجدول: حلقة تركيز مرئية، وكل هدف ≥ 44px.
- شاشة فارغة وشاشة خطأ في أي مورد: أيقونة + رسالة + إجراء.
- `prefers-reduced-motion`: لا حركة على التحويم ولا في الظهور.
