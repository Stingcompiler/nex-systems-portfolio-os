import type { Config } from 'tailwindcss';

/**
 * كل الألوان تمر عبر متغيرات CSS دلالية معرّفة في globals.css،
 * فيصبح تبديل الوضع الفاتح والداكن مجانيًا ولا يُكتب لون خام في أي مكوّن.
 */
const config: Config = {
  darkMode: 'class',
  content: ['./src/**/*.{ts,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        background: 'rgb(var(--background) / <alpha-value>)',
        surface: 'rgb(var(--surface) / <alpha-value>)',
        'surface-hover': 'rgb(var(--surface-hover) / <alpha-value>)',
        foreground: 'rgb(var(--foreground) / <alpha-value>)',
        muted: 'rgb(var(--foreground-muted) / <alpha-value>)',
        border: 'rgb(var(--border) / <alpha-value>)',
        primary: {
          DEFAULT: 'rgb(var(--primary) / <alpha-value>)',
          foreground: 'rgb(var(--primary-foreground) / <alpha-value>)',
        },
        accent: 'rgb(var(--accent) / <alpha-value>)',
        success: 'rgb(var(--success) / <alpha-value>)',
        warning: 'rgb(var(--warning) / <alpha-value>)',
        danger: 'rgb(var(--danger) / <alpha-value>)',
        ring: 'rgb(var(--ring) / <alpha-value>)',
      },
      fontFamily: {
        sans: ['var(--font-sans)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      fontSize: {
        display: ['clamp(2.5rem, 5vw + 1rem, 3.75rem)', { lineHeight: '1.15' }],
        h1: ['clamp(2rem, 3vw + 1rem, 2.75rem)', { lineHeight: '1.2' }],
        h2: ['clamp(1.6rem, 2vw + 0.75rem, 2rem)', { lineHeight: '1.3' }],
        h3: ['clamp(1.25rem, 1vw + 0.75rem, 1.375rem)', { lineHeight: '1.4' }],
      },
      maxWidth: {
        content: '80rem',
        prose: '72ch',
      },
      borderRadius: {
        sm: '0.375rem',
        DEFAULT: '0.625rem',
        lg: '0.875rem',
        xl: '1.25rem',
      },
      boxShadow: {
        // ظلال مصمّمة بطبقات، مدركة للوضع الداكن عبر المتغيرات
        subtle: 'var(--shadow-sm)',
        card: 'var(--shadow-md)',
        elevated: 'var(--shadow-lg)',
      },
      backgroundImage: {
        brand: 'var(--gradient-brand)',
      },
      transitionDuration: {
        fast: 'var(--duration-fast)',
        normal: 'var(--duration-normal)',
        slow: 'var(--duration-slow)',
      },
      keyframes: {
        'fade-up': {
          from: { opacity: '0', transform: 'translateY(12px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        'fade-up': 'fade-up var(--duration-normal) ease-out both',
      },
    },
  },
  plugins: [],
};

export default config;
